# Introduction

###  A function f is a rule that assigns each element x in a set D **exactly one** element called f(x) in a set E 
- We can use the vertical line test to test if the above statement is true, 
	- ![[Pasted image 20230512132952.png]]
	- 
- D is referred to as the domain of the function, while E is referred to as the range of the function 
- The domain is the set of all possible inputs and the range is the set of all possible outputs
- ![[Pasted image 20230510110124.png]]


### Piece-wise functions 
![[Pasted image 20230510110608.png]]y
![[Pasted image 20230510110621.png]]


### Odd and even functions 
- If f(x) = f(-x) ---> function is an **even function** and is considered symmetrical with respect to the y axis. 
	- We can sketch the entire graph by simply reflecting the graph across the y-axis
![[Pasted image 20230510111042.png]]



- if f(-x) = -f(x) ---> function is an **odd function** and is considered symmetrical with respect to the x axis
	- We can sketch the entire graph by first reflecting across the x-axis, then across the y axis 
![[Pasted image 20230510111057.png]]


### Increasing and decreasing functions 
- Function is increasing on interval i, if f(x1) < f(x2) for x1 < x2 in i 
- Function is decreasing on interval i, if f(x1) > f(x2) for x1 > x2 in i 

**- Note: The inequality must be satisfied for every single pair of numbers x1 and x2 in  interval i** 




# Function families 

### Linear functions 
- Linear function are graphed as a line and they have all have the same form of 
- $y=f(x)=mx+b$
- m is the slope of the line and b is the y-intercept 


### Polynomial functions 
- A function P is called polynomial if 
- ![[Pasted image 20230510112052.png]]
- Where a0, a1, ..., an are constants called **coefficients** of the polynomial 
- Note that each of coefficients can be equal to 0, so some terms can be removed
- The domain of any polynomial is $R=(-\infty,\infty)$
- The term with the largest degree defines the degree of the polynomial 
- ![[Pasted image 20230510112416.png]]
- For example P(x) has $2x^6$ therefore its degree is 6 
- Degree 1 = linear function, Degree 2 = quadratic function, Degree 3 = cubic function 
- ![[Pasted image 20230510114945.png]]


### Power functions 
- A function of the form $f(x) = x^a$ , where a is a constant is called a power function 
- There are several cases of power function 
##### a = n, where n is a positive integer
- Below are the graphs of $f(x) = x^n$ where **n = 1,2,3,4,5** 
- ![[Pasted image 20230510113319.png]]
- Notice that when **n is even** we get an even function, and when **n is odd** we get an odd function 
- As n increases,  functions tend to get flatter around x=0 and steeper for $|x| \geq 1$
- ![[Pasted image 20230510124634.png]]
##### a = 1/n, where n is a positive integer 
- The function $f(x)=x^{1/n}=\sqrt[n]{x}$ is a root function 
- Domain is $[0,\infty]$ for n even and is $\mathbb{R}$ for n odd
	- The domains differ because you cannot multiply $2^n$ identical numbers together and get a negative number, but you can multiply $3^n$ identical numbers together and get a negative
- Even **n** will be similar to $f(x)=\sqrt{x}$, while odd n will be similar to $f(x)=\sqrt[3]{x}$ 
- ![[Pasted image 20230510114818.png]]

##### a=-1 
- The reciprocal function $f(x) = x^{-1} = 1/x$ 
- ![[Pasted image 20230510124334.png]]

### Rational functions 
![[Pasted image 20230510124714.png]]

### Algebraic functions
- A function constructed using algebraic operations (addition, subtraction, multiplication, roots)
![[Pasted image 20230510124911.png]]

### Trigonometric functions 
- ![[Pasted image 20230510125149.png]]
- Note that sine and cosine function are periodic, and have a period of $2\pi$. This means that for all $x$ 
- ![[Pasted image 20230510125127.png]]


### Exponential functions 
- Functions of the form $f(x) = a^x$ where $a$ is some positive constant 
- Domain is $(-\infty,\infty)$ and the range is $(0,\infty)$ 
- ![[Pasted image 20230510125705.png]]

### Logarithmic functions 
- Functions of the form $f(x) = \log_{a}{x}$ where a is a positive constant, 
	- $y = log_{a}{x} ---> a^y = x$ 
- These are the inverse functions of exponential functions 
- Domain is $(0,\infty)$and the range is $(-\infty,\infty)$ 
- ![[Pasted image 20230510125927.png]]

# Transformations of functions 
- We can add/subtract constants, or multiply/divide functions to transform them to the graph we need 
### Translations
- Translations are adding/subtracting constants to the function to shift it right,left,down, or up
- ![[Pasted image 20230510130506.png]]
- ![[Pasted image 20230510130514.png]]

### Stretching and reflecting 
##### Stretching 
- Stretching is multiplying the function by some positive constant $c$, if $c>1$ then the graph is stretched by factor c , if $c<1$ then the graph is shrunk by a factor of c
- may be applied to x directly or the output which will effect if the stretch/shrink is vertically or horizontally applied 
	- If $c$ is effecting the output, the transformation is applied vertically 
	- if $c$ is effecting the input, the transformation is applied horizontally
- ![[Pasted image 20230510132117.png]]
	- Note that any division can be converted to multiplication
- ![[Pasted image 20230510132516.png]]

##### Reflecting 
- Reflecting is multiplying the function by -1, and a vertical reflection or horizontal reflection occurs depending on if $-1$ is effecting the input or output. 
- ![[Pasted image 20230510132410.png]]

### Combinations of functions 
- 2 functions f and g can be combined to form new functions f+g, f-g, fg, and f/g, similar to how we add, subtract, multiply, and divide real numbers.
- $(f+g)(x) = f(x)+g(x)$ and $(f-g)(x)= f(x)-g(x)$ 
	- If the domain of f is A and domain of g is B, then the domain of f+g is the intersection $A\cap B$, as both f(x) and g(x) have to be defined 
- $(fg)(x)=f(x)g(x)$ and $(\frac{f}{g})(x) = \frac{f(x)}{g(x)}$ 

### Composition 
- We can pass outputs from a function to another function, which is called composition
- ![[Pasted image 20230510133701.png]]
- ![[Pasted image 20230510133711.png]]


# Inverse functions 
- The inverse of a function is denoted by $f^{-1}(x)$ 
- ![[Pasted image 20230512133227.png]]
### One to one function 
- A function is considered "one to one" if f does not take the same value twice, 
- ![[Pasted image 20230512133438.png]]
- We can use a horizontal line test (similar to vertical line test )
- ![[Pasted image 20230512133513.png]]
##### Only one to one function have an inverse ! 

### Domain and range 
![[Pasted image 20230512133616.png]]

