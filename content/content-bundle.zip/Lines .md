### Slope of  a Line 
- The slope of a line can be computed using the idea of a triangle 
![[Pasted image 20230516141412.png]]
- The slope can be though of the ratio of the triangle's $height / width$


### Point slope form 
- The previous equation we had to determine the slope can be rewritten an equation of a line that passes through the point $(x_{1},y_{1})$ 
- Rewriting $\frac{y-y_{1}}{x-x_{1}}=m$ ---> $y-y_{1} = m(x-x_{1})$ 



### Slope intercept form 
- Suppose a line has slope $m$ and y-intercept $b$. This means we know the point $(0,b)$ 
- Using the point slope form from before we get $y-b = m(x-0)$ 
- This simplifies to 
	![[Pasted image 20230516142051.png]]
