[[Linear regression]]


# Setting up the problem
- ![[Pasted image 20230519163230.png]]
- Before our problem was working with some data ${ (x_{1},y_{1}), (x_{2},y_{2}), ..., (x_{n},y_{n})}$ for n data points, now our data set is ${ (\vec{x_{1}},y_{1}), (\vec{x_{2}},y_{2}), ..., (\vec{x_{n}},y_{n})}$  where $x_{i}$  is now a vector not a scalar. 
- Our model before was in the form of $y=ax+b$ and we were solving for 2 parameters $a$ and $b$ to find the most "optimal values", this is learning part of the process. 
- Now our model is $\hat{y}=w_{1}x_{1}+w_{2}x_{2},...,w_{D}x_{D}+b$ where $D$ to the Dimensionality of $x$ 

### Bias term 
- To simplify future calculations we can actually just absorb b into w be appending an extra term $x_{0}$ which is always equal to 1 therefore $w_{0}x_{0}=b$ 
- Therefore our equation is now 
   $$\large\hat{y}=w_{0}x_{0} + w_{1}x_{1}+w_{2}x_{2},...,w_{D}x_{D}+b,where\;x_{0}=1$$

# The data matrix X
![[Pasted image 20230519165423.png]]
- We can think the sum of all the $x_{i}$ terms as a matrix instead of row vectors where each row of a matrix $X$ represents 1 sample 
$$X=
\Bigg\{\begin{array}{rcl}
		x_{1,1}&x_{1,2}&...&x_{1,D} \\
		x_{2,1}&x_{2,2}&...&x_{2,D} \\
		...&...&...&... \\
		x_{N,1}&x_{N,2}&...&x_{N,D} \\
\end{array}\Bigg\}_{N\times D}  
$$

- Our matrix W needs to be transposed so we can do matrix multiplication, as the inner dimensions must match, therefore W must be a column vector of size $D\times1$ 
- So for a single sample prediction $\hat{y_{i}}=w^{T}x_{i}$ , we have 
- $$
 y_{1} = w^{T}x_{1=}
\Bigg\{\begin{array}{rcl}
		w_{1}&w_{2}&...&w_{D} \\
\end{array}\Bigg\}_{1\times D}  \times 

\Bigg\{\begin{array}{rcl}
	x_{i,1}\\
	x_{i,2}\\
	.. \\
	x_{i,D}\\
\end{array}\Bigg\}_{D\times 1} = w_{1}x_{i,1}+w_{2}x_{i,2}+...+w_{D}x_{i,D} 
$$
![[Pasted image 20230519172206.png]]
- Instead of calculating each $y_{i}$ on its own we can just do all the calculations by multiplying $w$ to the entire matrix $X$ 
- This will return a vector $\vec{y}$  of size $N\times 1$ that contains all of the predictions for the sample size 
- ![[Pasted image 20230519172608.png]]
- So the vector  $\vec{y} = [3,2,1,3]$ contains the predictions for the entire dataset. 
- ![[Pasted image 20230519172736.png]]


# Solving the equation
- In linear regression we were trying to solve for 2 variables $w_{1}=a$ and $w_{0}=b$ with Dimensionality=1
- Now we are solving for D dimensions with D variables $w_{0},w_{1},...,w_{D}$ 
- We can use the same equation from before
- We need to remember that there are$j=1,...,D$ equations here, so we are essentially solving for D equations and D unknown 
- ![[Multiple linear regression 2023-05-19 17.55.19.excalidraw]]
- 