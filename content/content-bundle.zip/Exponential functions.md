- In general the exponential function can be defined as 
$f(x) = a^x$ 
- Where a is a positive constant  

#### Types 
- if $x = n$, a positive integer then 
	- $a^n = a * a * a ... a$ 

- If $x = 0$ then $a^0=1$ 
- If $x=-n$  where n is a positive integer then 
	- $a^{-n} = \frac{1}{a^{n}}$ 
- If x is a ration number, $x=\frac{p}{q}$ where p and q are integers and q>0
	- $a^x= a^{\frac{p}{q}} = \sqrt[q]{a^p}=(\sqrt[q]{a})^{p}$   
- What is the meaning of $a^x$ if x is an irrational number? 
	- What is meant by $2^\sqrt{3}$ or $5^{\pi}$ 
- Lets take a look at the graph of $f(x)=2^x$, there are holes in the graph where there are irrational numbers
- ![[Pasted image 20230512131715.png]]
##### Proof
![[Pasted image 20230512131842.png]]
- We can use this idea for any $a^x$ 

##### 3 Types of exponential functions 
![[Pasted image 20230512132013.png]]


##### Laws of exponents 
- If x and y are rational numbers then these laws are true 
- ![[Pasted image 20230512132130.png]]

#### Natural exponential function

- Below look at the tangent lines to the graphs $y=2^x$ and $y=3^x$ at the point (0,1)
- ![[Pasted image 20230512132344.png]]
- Some of the formulas in calculus will be much simpler if we use a constant a that has a slope of 1 at the point (0,1)
- This constant a is referred to as $e\approx 2.71828$ 
- This is the natural exponential function 
- ![[Pasted image 20230512132544.png]]