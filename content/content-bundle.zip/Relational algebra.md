## Introduction 
- Query languages: Allow for manipulation and retrieval of data from a database. Allow Database System to optimize the queries automatically. 
- Query langues != programming languages (Not Turing complete )
- Not intended to be used for complex calculations 
	- Examples
		- Ask user for additional input
		- Handle non-relational data
		- Create visualisations 

## Formal query languages 
- 2 Mathematical query language form the foundation for "real" languages (eg: SQL) and for implementation 
	- Relational Algebra (RA):sers describe what they want, rather than how to compute it. (Non-procedural, declarative.)



## Relational algebra 
- Similar to mathematical algebra, you can form expressions using operators and operands, expressions have commutativity or associativity
- In RA operands are relations/tables 


#### Operators 
**- Selection ($\sigma$)**
	- Selects a subset of rows from relation 
	- No duplicates in result 
	- Schema of result identical to input relation
	- Selection conditions 
		- Simple conditions: comparing attributes values and/or constants
		- Complex conditions: combine simple conditions using **AND** and **OR**
**- Projection ($\pi$)**
	- Deletes unwanted columns from relation
	- Deletes duplicates since relations are sets 
**- Cartesian product (X)**
	- Combine two input relations 
	- Each tuple of 1st relation is paired with each tuple of 2nd relation
	- There might be 2 attributes with identical names, in this case use renaming
**- Set-Difference (-)**
	- Tuples in relation 1 *but not in* relation 2 
**- Union (U)**
	- Tuples in relation 1 *or* in relation 2 
- Intersection ($\cap$)
	- Tuples in relation 1 *and* in relation 2 
**- Renaming ($\rho$)**
	- Renaming relations / attributes without changing instance 
	- 3 different syntax 
		1. Rename relation and **all** attributes $\rho$ **S** (A1,A2,A3,...,An)(**R**)
			- Relation R is renamed to S
			- Attributes are renamed A1, ..., An
		2. Rename only some attributes $\rho$ **S** (1--> A1,..., 1 --> Ak)(**R**)
			- Use positional notation to reference attributes 
		3. No renaming of attributes  $\rho$ **S** (**R**)
**- Join ($\Join$)**
	- Similar to Cartesian product but has conditions, each tuple is paired if the 2 tuples satisfy the **join condition**
	- 3 different types of Joins 
		1. Theta Join: R $\Join_C$ S , where C is the condition (Eg. R.sid < S.sid)
		2. Equi-Join: Theta join where C is a attribute and tuples of the given attribute must be equal. 
			- **Note:** The resulting schema has only 1 copy of attribute given for condition
		3. Natural join: Equi-join on **all** common attributes 

**- Division (/)**
	- Create a new relation using tuples in relation 1 which are qualified based on relation 2 
	- Checking for pairs in relation 1 that are defined by relation 2 
	- Example A/B, A has 2 attributes x,y. B has only has 1 attribute y, the result would contain all tuples such that every y tuple in B there is an xy tuple in A. 


## Simple examples 

![[Relational algebra 2023-04-13 16.01.33.excalidraw.png]]

![[Pasted image 20230413185421.png]]


## Formulating RA queries 
##### Steps 
- Which relations do we need 
	- Joins 
- Which tuples do we need 
	- Selections 
- Which attributes do we need 
	- Projections 
##### Renaming 
- The renaming operation can be used to break down complex queries into multiple steps 


## Complex examples 

**Consider the following schema of a Company database: 
Employees(eid: integer, ename: string, address: string, supereid: integer) 
Departments(did: integer, dname: string) 
Projects(pid: integer, pname: string, did: integer) 
Works_on(eid: integer, pid: integer, hours: integer)** 

Each Employee has a supervisor (another Employee) referenced by his/her supereid. Projects are uniquely assigned to a Department. 

The Works_on relation records which Employee works on which Project for how many hours a week. 

Formulate each of the following queries in relational algebra (RA): 
a) For each Employee, find their name and the name of their supervisor. 
b) Find the eids of Employees who work on a project of every Department, i.e. find the eids of Employees who work for at least one project of every Department. 
c) Find the pid of Projects for which at least two different Employees work.

![[RA example 2023-04-13 19.07.02.excalidraw.png]]


## Optimising RA queries 

- After a user formulate a SQL query, a query optimiser translates this query into a **equivalent** RA query
- To optimise the efficiency of query processing the optimiser can re-order the individual operations within the RA query 
- The re-ordering has to preserve the query meaning and is based on RA equivalences 
- Example
	- ![[Pasted image 20230416150715.png]]


## RA algebra equivalences 
- Needs to be completed........





