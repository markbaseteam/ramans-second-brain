# Functions of several variables 

### Functions of two variables
![[Pasted image 20230517103604.png]]
- Some examples of functions with 2 two variables are 
	- The volume of a circular cylinder $V(r,h) = \pi r^2 h$ 
- ![[Pasted image 20230517103730.png]]
- We often write z = f(x,y) where x and y are independent variables and z is the dependent variable
- Example: 
	- Find the domain of $f(x,y) = \frac{\sqrt{x+y+1}}{x-1}$
	- ![[Pasted image 20230517104150.png]]
	- ![[Pasted image 20230517104102.png]]
	- The vertical line x=1 is excluded from the domain

##### Graphs 
- ![[Pasted image 20230517104345.png]]
- ![[Pasted image 20230517104440.png]]
- We can visualize the graph of S as lying directly above/below its domain D in the xy plane. 
- The z dimension is the one changing based on the domain, while the domain remains constant. 










# Partial derivatives 
- Suppose f is a function of 2 variables x and y, suppose we only let x vary while y fixed say y=b, where b is a constant 
- Then we are only considered the function of a single variable x, $g(x) = f(x,b)$
- If g has a derivative at a, then we call it the **partial derivative of f with respect to x at (a,b)** and denote it by $f_{x}(a,b)$
- ![[Pasted image 20230517110012.png]]
- By the definition of a derivative we have 
- ![[Pasted image 20230517110042.png]]
- ![[Pasted image 20230517110148.png]]
##### Notation for partial derivatives 
![[Pasted image 20230517110242.png]]
![[Pasted image 20230517110318.png]]






