![[Pasted image 20230517112553.png]]
![[Pasted image 20230517112608.png]]
![[Pasted image 20230517112513.png]]
- Note that we use the square of the error to counteract the fact that any given error can be positive or negative! 
- We want to find E such that E is the smallest possible value for the sum of squared errors. We are trying to minimize E
- ![[Pasted image 20230517112833.png]]
- We want to minimize E with respect to $a$ and $b$, we can use partial derivatives 
- ![[Linear regression 2023-05-17 11.31.54.excalidraw]]

### Programming linear regression using numpy 
- In order to make the computation of $a$ and $b$ easier we can actually use. 
- We can actually re-write the equation we just derived to something simpler that will make it easier to calculations with Numpy 
- ![[Linear regression 2023-05-20 16.12.14.excalidraw]]
