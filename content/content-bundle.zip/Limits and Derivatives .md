# The tangent line 

- A tangent line is a line that touches the curve/function at exactly one point (We will further define this)
- Since the tangent line only touches the line at one point we cannot determine the equation of the line 
- We can use a a line defined by 2 points on a curve called a **secant line** to help us 
- ![[Pasted image 20230516142453.png]]
- The slope of this secant line can be defined as 
	- $\frac{y-1}{x-1}$ 
- For example for the point Q(1.5,2.25) we have 
	- $m_{pq} = \frac{2.25-1}{1.5-1} = \frac{1.25}{0.5} = 2.5$ 
- As we pick a point Q closer and closer to P, the slope will approach the slope of the line $t$ 
- ![[Pasted image 20230516142853.png]]
- This is the idea of a limit 
- ![[Pasted image 20230516142921.png]]
- The slope of the tangent line is then 
	- ![[Pasted image 20230516142957.png]]
- ![[Pasted image 20230516143052.png]]

# The limit of a function 
- Now we can start to look at limits in general and numerical and graphical methods to solve them 
- From the graph below we can see that as x **approaches** 2 that is sufficiently close to 4 
- ![[Pasted image 20230516143305.png]]
- We can then say that "limit of this function as x approach 2 is equal to four"
- ![[Pasted image 20230516143346.png]]
- ![[Pasted image 20230516143357.png]]
- Using this same idea we can compute the limit of a function from only one side 
- ![[Pasted image 20230516143651.png]]
- Sometimes when we take a limit we dont converge to a number using a numerical method, instead numbers may become infinitely large 
- In this case we say that limit does not exist 
- ![[Pasted image 20230516143951.png]]
- ![[Pasted image 20230516144052.png]]
- ![[Pasted image 20230516144110.png]]





# Calculating limits using the limit laws

![[Pasted image 20230516144222.png]]
![[Pasted image 20230516144257.png]]
![[Pasted image 20230516144357.png]]
![[Pasted image 20230516144435.png]]
- If we are working with a function that is continuous at $a$ then
	- ![[Pasted image 20230516144552.png]]
- If there are 3 function squeezed together at some point $a$ then their limits can be considered equal 
	- ![[Pasted image 20230516144853.png]]



# Precise definition of a limit
![[Pasted image 20230516161954.png]]
![[Pasted image 20230516162006.png]]
- unfinished 






# Continuity 
![[Pasted image 20230516162305.png]]


- If $f$  is defined near $a$ but not at $a$ we say that f is **discontinuous at $a$**
- You can draw the graph of a continuous function with one uninterrupted stroke pen. 
- ![[Pasted image 20230516163551.png]]
- ![[Pasted image 20230516163622.png]]
- ![[Pasted image 20230516163653.png]]
- ![[Pasted image 20230516163712.png]]
- ![[Pasted image 20230516163730.png]]
- ![[Pasted image 20230516163751.png]]
- ![[Pasted image 20230516163810.png]]
##### Intermediate Value Theorem 
![[Pasted image 20230516163855.png]]
![[Pasted image 20230516163932.png]]

