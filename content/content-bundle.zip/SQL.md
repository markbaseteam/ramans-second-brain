- SQL is the standard query language for relational DBS 
- Any RA query can also be formulated in SQL but in a more user friendly manner 
- SQL has further features and functionalities compared to RA 


## Basic SQL Query 

**SELECT [DISTINCT] target-list
FROM relation-list 
WHERE qualification 
**

- **target-list:** list of attributes of relations in relation-list 
- **relation-list:** list of relation names 
- **qualification:** comparisons (`attribute op constant` or `attribute1 op attribute2`, where op is one of **<.>,=, etc...** combined using **AND**,**OR** and **NOT** )

- DISTINCT is optional to indicate result doesn't contain duplicates. Default is result contains duplicates! 


### SQL Query steps
- Compute the Cartesian product of the relation-list 
- Selection of the tuples satisfying the qualifications 
- Projections onto the attributes that are in the target list
- Often helpful to write Query in the same order (SELECT, FROM, WHERE)




### Projection 
- Expressed through the **SELECT** clause 
- Can specify any subset of the set of all attributes 
	- SELECT attribute1, attribute2, etc...
	- FROM Relation; 
- `*` selects *all* attributes 
- Can rename attributes using **AS**
- For numeric attributes, can also apply arithmetic operators
- Can create derived attributes and name then using AS or "="
```SQL
	SELECT age AS age0, age1=age-5, 2*S.age As age2
	FROM Sailors;
```
- It is considered good style to always use tuple variables 
```SQL
SELECT R.attribute1
FROM Relation R
WHERE R.attribute2 > 5;
```
- To eliminate duplicates use **DISTINCT** in the **SELECT** clause
	- SELECT DISTINCT age
	- FROM Sailors; 



### Selection 
- Expressed through the **WHERE** clause 
- Selection conditions can compare constants and attributes of relations mentioned in the **FROM** clause
- Can use comparison operators, for numeric attributes can also apply arithmetic operators, simple conditions can be combined using AND, OR, NOT. 
- Use parentheses to change the order of operations 
- Example 
	- SELECT * 
	- FROM Sailors 
	- WHERE (rating = 5 OR rating =6) AND age<=20; 

### String comparisons 
- Suppose you have a table named "customers" that contains a column named "customer_name". You can use the LIKE operator to find all customers whose names begin with the letter "J" and have a six-letter name, using the following query:
```SQL
SELECT * 
FROM customers 
WHERE customer_name LIKE 'J_____'`
```
- In this query, the underscore represents any single character, and the five underscores following the letter "J" represent the remaining five letters of the name.
- You can also use the percent sign to find all customers whose names contain the string "son". For example:
```SQL
SELECT * 
FROM customers 
WHERE customer_name LIKE '%son%'

```
- In this query, the percent signs before and after the string "son" represent any number of characters that may occur before or after the string "son" in the customer name.


### Null values 
- Nulls can be interpreted as: 
	- Value unknown 
	- Value inapplicable/invalid 
	- Value withheld (eg. For security purposes)
- Null values complicate many issues, for example dealing with NULL values in logical statements. 
- Rules for NULL values: 
	- An arithmetic operator with at least one NULL argument always returns NULL
	- the comparison of a NULL value to any other value returns a result of UNKNOWN
- A selection returns only the tuples that make the condition in the WHERE clause TRUE, those with UNKNOWN or FALSE result do not qualify 
##### Solution 
- Three-valued logic: TRUE, UNKNOWN, FALSE
- Can think of TRUE = 1, UNKNOWN = 1/2, FALSE = 0
- AND of two truth values ---> their minimum 
- OR of two truth values ---> their maximum 
- NOT of a truth value: 1 - the value
- Examples
	- TRUE AND UNKNOWN = 0.5 / UNKNOWN
	- FALSE AND UNKNOWN = 0 / FALSE
	- FALSE OR UNKNOWN = 0.5 / UNKNOWN
	- NOT UNKNOWN = 0.5 / UNKNOWN 
- SQL example 
``` SQL
	SELECT * 
	FROM Sailors 
	WHERE rating < 5 or rating >= 5
```
- Does not return all sailors, only those with non-NULL ratings 


### Ordering the input 
- Can order the output of a query with respect to any attribute or list of attributes
- Add ORDER BY clause to query 
```SQL
SELECT *
FROM Sailors S
WHERE age < 20 
ORDER BY rating: 
```
- By default ascending order, use DESC for descending order 


##### Cartesian product 
- Expressed in the FROM classmusfinal_dft 
- Creates a Cartesian product of all relations in the given order
```SQL
SELECT *
FROM Sailors, Reserves
```

##### Join 
- Expressed through the FROM clause and WHERE clause
- Forms a subset of the Cartesian product of tuples that satisfy the where condition 
```SQL
SELECT *
FROM Sailors, Reserves
WHERE Sailors.sid = Reserves.sid; 
```

- Shorthand version 
```SQL
SELECT *
FROM Sailors JOIN Reserves ON
	Sailors.sid = Reserves.sid;
```
- Natural Join 
```SQL
SELECT *
FROM Sailors NATURAl JOIN Reserves;
```
- Dangling tuples in one of the input relations that have no matching tuple in the other relation, so they are not contained in the output
- Outer joins are join variants that don't lose information from the input relations
	- LEFT OUTER JOIN: includes all dangling tuples from the **left** input relation with NULL values filled in for all the attributes of the **right** input relation 
	- RIGHT OUTER JOIN: includes all dangling tuples from the **right** input relation with NULL values filled in for all the attributes of the **left** input relation 
	- FULL OUTER JOIN: includes all dangling tuples from both input relations



### Set operations 
- SQL supports 3 basic set operations 
	- UNION 
	- INTERSECT 
	- EXCEPT (set-difference)
- Two input relations must have identical schemas

###### Example 
---
Find sids of sailors who have reserved a red or a green boat **without** set operations
```SQL
SELECT S.sid 
FROM Sailors S, Boats B, Reserves R 
WHERE S.sid=R.sid AND R.bid=B.bid AND (B.color=red OR B.color=green);
```
- This query is taking the Cartesian product of the 3 relations, then using selection to find the sailors who reserved a red or a green boat
--- 
Find sids of sailors who have reserved a red or a green boat **with** set operations
```SQL
SELECT S.sid 
FROM Sailors S, Boats B, Reserves R 
WHERE S.sid=R.sid AND R.bid=B.bid AND B.color=red
UNION
SELECT S.sid 
FROM Sailors S, Boats B, Reserves R 
WHERE S.sid=R.sid AND R.bid=B.bid AND B.color=green;
```
- This query finds the sailors who have reserved a red boat and combines it with another query of sailors who reserved a green boat
- If we used INTERSECT instead of UNION we would find the sailors who have reserved **a red and a green** boat 



### Subqueries
- A subquery is a query nested within another SQL query, similar to nested loops
- Subqueries can 
	- return a single constant that can be used in the WHERE clause
	- return a relation that can be used in the WHERE clause
	- appear in the FROM clause 
- Subqueries can contain further subqueries 

###### Single constant 
- The result of a subquery returning a single constant can be compared using operators 
Example 
```SQL
SELECT S.age 
FROM Sailors S 
WHERE S.age > (SELECT S.age FROM Sailors S WHERE S.sid=22);
```
- Need to ensure that the subquery only returns one constant ! 

###### Relation 
- The output of a subquery returning a relation R can be compared using the special operators 
	- **EXISTS** R is true if and only if R is non-empty
	- t **IN** R is true if and only if tuple(constant) t is contained in R
	- t **NOT IN** R is true in and only if tuple t is not contained in R
	- t op **ALL** R is true if and only if constant t fulfills op with respect to every in R
	- t op **ANY** R is true if and only if constant t fulfills op with respect to at least on value in R
- Op can be one of >, <,=, >=, <=, != 
- EXISTS, ALL, and ANY can be negated by putting **NOT** in front of the expression 

###### FROM Clause
- In a FROM clause we can substitute a  parenthesised subquery instead of a relation
- Need to define a tuple variable (A tuple variable is a variable that represents a single tuple or row in a relation) for the subquery output 
```SQL
SELECT * 
FROM Reserves R, (SELECT S.sid FROM Sailors S WHERE S.age>60) OldSailors 
WHERE R.sid = OldSailors.sid;
```
- In this case **OldSailors** is the tuple variable 

###### Correlated subqueries
- A subquery can be correlated to the outer query if it uses values from the outer-query to compute its result. 
- The result of this is a re computation of the subquery for each row of the outer query to pass values from the outer query into the subquery 
- Example 
```SQL 
SELECT B.bid 
FROM Boats B 
WHERE NOT EXISTS (SELECT * FROM Reserves R WHERE R.bid=B.bid);
```
- In this case the subquery is correlated to the outer query by using the Boats relation with `B.bid`


###### Division in SQL
- We can use the EXCEPT (set-difference) clause
- We can also do this without EXCEPT but its longer and less concise
*- Find sailors who have reserved all boats*
```SQL
SELECT S.sname
FROM Sailors S
WHERE NOT EXISTS (
    (SELECT B.bid
     FROM Boats B)
    EXCEPT
    (SELECT R.bid
     FROM Reserves R
     WHERE R.sid=S.sid)
);
```
- First we find all the boat id's that are reserved by the current sailor
- We then take the set difference of these boat id with the list of all boat id's 
- If this difference is empty then the NOT exists returns true and that sailor has reserved all boats
- We loop through all sailors and perform the subquery 



##### Aggregation operators
- These operators work on a **set** of tuples
	- COUNT ($*$): the number of tuples 
	- COUNT ([DISTINCT] A): the number of (unique) values in attribute A
	- SUM ([DISTINCT] A): the sum of all (unique) values in attribute A
	- AVG ([DISTINCT] A): the average of all (unique) values in attribute A
	- MAX (A): the maximum value in attribute A
	- MIN(A): the minimum value in attribute A
- Note that aggregation operators cannot be nested! 


##### GROUP BY and HAVING
- Sometimes we want to apply aggregation operators to several groups of tuples 
```SQL
SELECT [DISTINCT] target-list 
FROM relation-list 
WHERE qualification 
GROUP BY grouping-list 
HAVING group-qualification ;
```
- A **group** is a set of tuples with the same value for all attributes in grouping list 
- Example: sailors with age of 18 would be a group if the grouping list contained Sailors.age
- The *target-list* contains attribute names and terms with aggregation operations
	- The attribute names ***must be contained*** in *grouping-list*
	- Only attributes defined in the target-list can be used in the GROUP BY and HAVING clauses

Example 
```SQL
SELECT department, gender, AVG(salary) AS avg_salary 
FROM employees 
GROUP BY department, gender;
```
- The group in this query is all combinations of department and gender (ie: Accounting/Female)
- The average salary is computed for all the groups
- **HAVING** is essentially the same as **WHERE** but for defining the groups 
- The condition of the **HAVING** clause be based on an aggregate function or a column that has a single value per group 
- ![[Pasted image 20230417150338.png]]

## SQL Modifications and Transactions 

- Three basic operations to modify the state of a DB
	- INSERT: inserts new tuples
	- DELETE: deletes existing tuples 
	- UPDATE: updates attribute values of existing tuples


##### Insertion

```SQL
INSERT INTO R(A1, ..., AN)
<subquery>; 
``` 
- Inserts a set of tuples (relation) with values for attributes Ai into table R as specified by a subquery
Example 
```SQL
INSERT INTO Sailors (sid) 
SELECT DISTINCT R.sid 
FROM Reserves R 
WHERE R.sid NOT IN 
	(SELECT sid FROM Sailors);
```
- The subquery is completely evaluated before the 1st tuple is inserted


##### Deletion 
```SQL
DELETE FROM R
WHERE <condition>;
```
- Deletes the set of all tuples from R that satisfy the condition
- Note: Cannot directly specify tuple to be deleted 
Examples 
```SQL
DELETE FROM Sailors  -- one tuple 
WHERE sid = 69; 

DELETE FROM Sailors -- multiple tuples 
WHERE rating < 3;
```

##### Update
```SQL
UPDATE R
SET <new value assignments>
WHERE <condition>;
```
- Updates attributes based on the SET assignment for all R tuples satisfying the condition
```SQL
UPDATE Sailors 
SET age = age + 1; 

UPDATE Sailors SET rating = rating * 1.1, age = age + 1 WHERE age < 30 and sid IN (SELECT R.sid FROM Reserves R);
```


### Transactions 
- DBS will have many concurrent users reading and writing the DB
- Each user may input a sequence of SQL statements that forms a transaction
- The DBS organises different users and transactions in a way that produces identical results if the statements were executed individually ***(Serializability)***
- Sometimes system errors can occur during a transaction, where only part of the transaction will be executed leaving the DB in an inconsistent state. The DBS must take an **all or nothing** approach to transactions ***(Atomicity)***
- ![[Pasted image 20230418103513.png]]


#### Serializability 
- Serializability is ensured by locking the DB objects read or written
- Serial schedule: Schedule that does not interleave the SQL statements of different transactions
- Before reading or writing a DB object, the transaction needs to obtain the appropriate lock 
	- Shared locks for reading
	- Exclusive locks for writing 
	- View locks to prevent new tuples from being returned by repeated reading
- Locks are released only at the end of a transaction 
- Transaction must wait for lock to be released if it is already being used 
- By default each SQL statement is treated as an individual transaction 
- Transactions can also be defined explicitly 
```SQL
START TRANSACTION;
	<sequence of SQL statements> 
COMMIT; 
or ROLLBACK; 
```
- COMMIT makes all modifications permanent, ROLLBACK undoes all DB modifications made by that transaction 

Example 
- S(...) = request a shared lock, X(...) request an exclusive lock, R(...) reading, W(...) writing
![[Pasted image 20230418095619.png]]



##### Reading 
- Shared locks do not have to wait for each other, 
- To specify the next transaction as read-only `SET TRANSACTION READ ONLY`
###### Dirty reads 
- Dirty data is data that has been modified by a transaction but hasn't been committed 
- If that transaction happens to be rolled back, a non-serialisable schedule results 
![[Pasted image 20230418103110.png]]
- With locks we get the following schedule 
![[Pasted image 20230418103135.png]]

#### Isolation levels
- SQL default isolation level ensures serializability
- There are situations where a weaker isolation level may be okay (and more efficient!)
- `SET TRANSACTION LEVEL ... ;`
- The isolation level of a transaction defines what data that transaction may see
- ![[Pasted image 20230418103346.png]]









